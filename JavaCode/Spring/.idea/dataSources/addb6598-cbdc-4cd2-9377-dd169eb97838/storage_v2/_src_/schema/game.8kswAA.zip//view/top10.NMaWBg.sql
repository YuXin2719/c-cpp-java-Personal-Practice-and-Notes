create definer = root@localhost view top10 as
select `game`.`player`.`id`    AS `id`,
       `game`.`player`.`name`  AS `name`,
       `game`.`player`.`sex`   AS `sex`,
       `game`.`player`.`email` AS `email`,
       `game`.`player`.`level` AS `level`,
       `game`.`player`.`exp`   AS `exp`,
       `game`.`player`.`gold`  AS `gold`
from `game`.`player`
order by `game`.`player`.`level`
limit 5;

